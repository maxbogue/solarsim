/*
- Collision detection
- Have a start page
- New skin or custom color
- Game over if you get hit?
- Continuous spawning of enemies (survival game?)
- Smaller enemies are faster
- Bounce off the edges
- Rainbow background?
- Have a trail (snake style)
*/

const HERO_SIZE = 20;

function randomInt(low, high) {
  return Math.floor(Math.random() * (high - low) + low);
}

function startGame(ctx) {
  const { width, height } = ctx.canvas;

  function randomPosition() {
    return {
      x: randomInt(0, width) - width / 2,
      y: randomInt(0, height) - height / 2,
    }
  }

  const state = {
    hero: { x: 0, y: 0, size: HERO_SIZE },
    enemies: [
      {
        ...randomPosition(),
        size: randomInt(10, 30),
      },
      {
        ...randomPosition(),
        size: randomInt(10, 30),
      },
      {
        ...randomPosition(),
        size: randomInt(10, 30),
      },
      {
        ...randomPosition(),
        size: randomInt(10, 30),
      },
    ],
  };

  function updateAndRender(elapsedMs, count) {
    step(state, elapsedMs, count);
    draw(ctx, state);
  }

  start(updateAndRender)
  return state;
}

/**
 * Generic function for starting and stopping a simulation.
 *
 * @param next The function that renders a frame of the animation. Should
 *             accept the elapsed time since last invocation in ms.
 * @returns A function that stops the render loop.
 */
 function start(next) {
  let lastMs;
  let frameId;
  let count = 0;

  // Renders a frame of the system on the canvas and schedules the next render.
  function render(totalMs = 0) {
    lastMs = lastMs || totalMs;
    const elapsedMs = totalMs - lastMs;
    lastMs = totalMs;
    count++;
    // If it's been more than a second, skip this frame.
    if (elapsedMs < 1000) {
      next(elapsedMs, count);
    }

    frameId = requestAnimationFrame(render);
  }

  render();
  return () => cancelAnimationFrame(frameId);
}

function direction(from, to) {
  const dx = to.x - from.x;
  const dy = to.y - from.y;
  const a = Math.atan2(dy, dx);
  return [Math.cos(a), Math.sin(a)];
}

function moveTowards(object, target, distance = 1) {
  const [dx, dy] = direction(object, target);
  object.x += dx * distance;
  object.y += dy * distance;
}

// Perform one step of the simulation.
function step(state, elapsedMs, count) {
  const { hero } = state;
  for (const enemy of state.enemies) {
    moveTowards(enemy, hero, 1)
  }
}

// Draw the entire system on the canvas.
function draw(ctx, state) {
  // Clear the canvas.
  ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
  // Draw the scene.
  drawHero(ctx, state.hero);
  for (const enemy of state.enemies) {
    drawEnemy(ctx, enemy);
  }
}

// Draw |object| on the canvas in |ctx|.
function drawHero(ctx, object) {
  drawSquare(ctx, object, '#00BB00');
}

function drawEnemy(ctx, enemy) {
  drawSquare(ctx, enemy, '#ff0000');
}

function drawSquare(ctx, object, color) {
  const { height, width } = ctx.canvas;
  const xOffset = width / 2
  const yOffset = height / 2;
  const { x, y, size } = object;
  // Draw the object and fill it with the color.
  //ctx.beginPath();
  //ctx.closePath();
  ctx.fillStyle = color;
  ctx.fillRect(
    xOffset + x - size / 2,
    height - (yOffset + y - size / 2),
    size,
    size
  );
  //ctx.fill();
}
